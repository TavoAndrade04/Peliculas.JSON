from pydoc import doc


def create_json_Peliculas():
    Titulo= input("Titulo: ")
    Genero = input("Genero: ")
    Director = input("Director: ")
    Actores = input("Actores: ")
    Pais =input("Pais: ")
    Fecha_Emision= input("Fecha_Emision: ")


    Peliculas = {
        "Titulo": Titulo,
        "Genero": Genero,
        "Director": Director,
        "Actores": Actores,
        "Pais": Pais,
        "Fecha_Emision": Fecha_Emision,
    }
    return Peliculas



def create_json_update_Peliculas():
    print("Menu de opciones ")
    print("1. Modificar todo el documento")
    print("2. Modificar solo un elemento del documento")
    opc = input("Ingrese una opcion: ")

    if opc == "1":
        Titulo = input("Titulo: ")
        Genero = input("Genero: ")
        Director = input("Director: ")
        Actores = input("Actores: ")
        Pais = input("Pais: ")
        Fecha_Emision = input("Fecha_Emision: ")


        Peliculas = {
            "Titulo": Titulo,
            "Genero": Genero,
            "Director": Director,
            "Actores": Actores,
            "Pais": Pais,
            "Fecha_Emision": Fecha_Emision,

        }
        return Peliculas

    elif opc == "2":
        indice = input("Ingrese el valor de indice a modificar: ")
        valor = input("Ingrese el valor a modificar: ")
        Peliculas = {indice: valor}
        return Peliculas


def read_books_date():
    print("\n-----¿Desea filtrar por fecha de publicacion?-----")
    print("1. Yes")
    print("2. NO")
    opc = input("\n Ingrese una opcion: ")

    if opc == "1":
        date = input("\n Ingrese fecha: ")
        query = {"Fecha_Emision": date}

        if date is doc:
            print("nnooooo")

        else:
            print("-------------> Fecha no encontrada")

    if opc == "2":
        print("\n----- Regresando al menu pricipal -----")
