from crud import *
from functions import *


class Fecha_Emision:
    pass


def show_Peliculas(Titulo):
    pass


while True:
    print("\n-------- Menu de opciones --------")
    print("1. Ver todos los registros")
    print("2. Buscar Pelicula por titulo")
    print("3. Insertar Pelicula")
    print("4. Actualizar Pelicula")
    print("5. Eliminar Pelicula")
    print("6. Salir de sistema")
    print("----------------------------------\n")

    opc = input("Seleccione una opcion: ")
    print("---------------------------\n")

    if opc == "1":
        Fecha_Emision()
        date = read_Fecha_Emision()
        Fecha_Emision(date)


    elif opc == "2":
        Titulo = input("Ingrese el titulo de la pelicula: ")
        show_Peliculas(Titulo)

    elif opc == "3":
        Peliculas = create_json_Peliculas()
        create_Peliculas(Peliculas)

    elif opc == "4":
        id = input("Ingrese el id de la pelicula a modificar: ")
        Peliculas = create_json_update_Peliculas()
        update_Peliculas(id, Peliculas)


    elif opc == "5":

        d = input("Ingrese el id de la pelicula"
                  " a eliminar: ")
        delete_Peliculas(d)



    elif opc == "6":
        print("------------------------> Saliendo del sistema")
        break