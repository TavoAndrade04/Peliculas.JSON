import json
from conection import collection
from bson.objectid import ObjectId

def read_Peliculas(id=None):
    if id is not None:
        query = {"_id": id}
        document = collection.find_one(query)
        print(json.dumps(document))
    else:
        documents = collection.find()
        for document in documents:
            print(document)

def read_Titulo(Titulo):
    query = {"Titulo": Titulo}
    print("Resultado: ")
    print(collection.find_one(query))
    print("\n")

def read_Fecha_Emision(date):
    cur = collection.find({"release_date": date})
    #query = {"release_date": date}
    #result = collection.find(date)
    if date == date:
        for i in cur:
            print(i)


    #find = collection.find(date)
    #for doc in find:
        #print(doc)
    #print("mira acá \n")

def create_Peliculas(Peliculas):
    result = collection.insert_one(Peliculas)
    print(result.inserted_id)
    print("Registrado con exito \n")


def update_Peliculas(id, json_indices_values):
    query = {"_id": id}
    new_values = {"$set": json_indices_values}
    result = collection.update_one(query, new_values)
    print(result.modified_count)
    print("Registro actualizado \n")


def delete_Peliculas(d):
    query = {"_id": d}
    result = collection.delete_one(query)
    print(result.deleted_count)




















